package com.zeenat.mehndistudio;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.print.*;
import android.webkit.*;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.view.*;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends AppCompatActivity {
    WebView web;
    static final int PICK_FILE=41;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        web=new WebView(this);
        web.setBackgroundColor(Color.rgb(251,247,241));
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new NativeBridge(), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    class NativeBridge {
        @JavascriptInterface public void toast(String msg){ runOnUiThread(()->Toast.makeText(MainActivity.this,msg,Toast.LENGTH_SHORT).show()); }
        @JavascriptInterface public void shareText(String text){
            Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT,text); startActivity(Intent.createChooser(i,"Share receipt"));
        }
        @JavascriptInterface public void printPage(){ runOnUiThread(()->{
            PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
            pm.print("Zeenat Receipt", web.createPrintDocumentAdapter("Zeenat Receipt"), new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());
        });}
        @JavascriptInterface public void savePdf(String htmlText){
            try{
                WebView w=new WebView(MainActivity.this); w.getSettings().setJavaScriptEnabled(true);
                w.setWebViewClient(new WebViewClient(){
                    @Override public void onPageFinished(WebView v,String u){
                        PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
                        pm.print("Zeenat Receipt",v.createPrintDocumentAdapter("Zeenat Receipt"),new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());
                    }
                });
                w.loadDataWithBaseURL(null, htmlText, "text/html","UTF-8",null);
            }catch(Exception e){toast("PDF failed: "+e.getMessage());}
        }
        @JavascriptInterface public void saveImage(String dataUrl,String filename){
            try{
                String b64=dataUrl.substring(dataUrl.indexOf(",")+1);
                byte[] data=android.util.Base64.decode(b64,android.util.Base64.DEFAULT);
                File f=new File(getExternalFilesDir(null),filename);
                try(FileOutputStream out=new FileOutputStream(f)){out.write(data);}
                Uri uri=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".files",f);
                Intent i=new Intent(Intent.ACTION_SEND);i.setType("image/jpeg");i.putExtra(Intent.EXTRA_STREAM,uri);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(i,"Save/share receipt image"));
            }catch(Exception e){toast("Image export failed");}
        }
        @JavascriptInterface public void openFilePicker(){
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_FILE);
        }
    }

    @Override protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d);
        if(r==PICK_FILE && c==RESULT_OK && d!=null && d.getData()!=null){
            Uri u=d.getData();
            try{
                String type=getContentResolver().getType(u);
                InputStream in=getContentResolver().openInputStream(u);
                ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;
                while((n=in.read(buf))!=-1)out.write(buf,0,n);in.close();
                String b64=android.util.Base64.encodeToString(out.toByteArray(),android.util.Base64.NO_WRAP);
                String js="window.nativeFilePicked && window.nativeFilePicked('data:"+(type==null?"image/jpeg":type)+";base64,"+b64+"')";
                web.evaluateJavascript(js,null);
            }catch(Exception e){ }
        }
    }

    @Override public void onBackPressed(){
        if(web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
